'use strict'


function showPersonTable (person) {
    randomUser.innerHTML += `
        <tr>
            <td><img src=${person.picture.thumbnail} alt="Random portrait" /></td>
            <td> 
                <a href="mailto:${person.email}">
                ${person.name.first} 
                ${person.name.last}</a>
            </td> 
            <td>${person.phone}</td> 
            <td>${person.location.city}</td> 
        </tr>
    `;
}

async function getRandomUser(event) {
    event.preventDefault();
    const targetID = event.target.getAttribute('id');

    const url = targetID === 'BrowserAccess' ? "https://randomuser.me/api/"
                : "/random-person"

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (response.status === 200) {
            showPersonTable(data.results[0]);
        }


    } catch (error) {
        console.error(error)
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const BrowserAccessLink = document.getElementById('BrowserAccess');
    BrowserAccessLink.addEventListener('click', getRandomUser);

    const ServerAccessLink = document.getElementById('ServerAccess');
    ServerAccessLink.addEventListener('click', getRandomUser);
});
