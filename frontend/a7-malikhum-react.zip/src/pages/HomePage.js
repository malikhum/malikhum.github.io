import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
   return (
      <>
        <header>
            <h1><strong>Humayl Malik</strong></h1>
        </header>
        <nav>
        <Link to="/">Home</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/gallery">Gallery</Link>
        <Link to="/order">Order</Link>
        <Link to="/staff">Staff</Link>
        </nav>
        <main>
            <section>
                <h2><strong>Web Development Concepts</strong></h2>
                <nav class="local-nav">
                    <a href="#forms">Forms</a>
                    <a href="#express">Express</a>
                    <a href="#JavaScript">JavaScript</a>
                    <a href="#DOM-Changes">DOM Changes</a> 
                </nav>
                <article>
                    <h3><strong>Web Servers</strong></h3>
                    <p>In relation to web servers, an index.html file is a default file that web servers look for when a
                        user requests to view a directory on a website. It is the default or home page for a website that is
                        displayed in a web browser when a user navigates to the website's domain name without specifying a
                        specific file or path.</p>
                    <p>The main difference between the two requests is the protocol used to access the file or server. In
                        the first request, the protocol used is “file:///“, which indicates that the file is being accessed
                        locally on the user's machine. The second request uses the “https://” protocol to access a remote
                        server. Additionally, the second request contains much more information about the server and the
                        response, including the server type, headers, while the first request only provides basic
                        information about the file and its content type. This is because the second request is a standard
                        HTTP request sent to a web server, while the first request is a simple file request made directly to
                        the user's file system.</p>
                    <p>In this case, the favicon.ico file is found and retrieved by the server, which is why a status code
                        of 200 is returned. On the other hand, the main.css and main.js files are not found by the server,
                        which is why a status code of 404 is returned.</p>
                    <p>The scheme is the first part of the URL. In the given URL, the scheme is “HTTPS”. The subdomain is
                        the part of the URL that comes before the domain name. In the URL, “web” is the subdomain. The host
                        domain is the part of the URL that identifies the website. In this URL, the subdomain is “web.engr”
                        and the domain is “oregonstate.edu”. The resource is the specific location of the file or resource
                        on the website. In this URL, the resource is “/~malikhum/a1-malikhum/“.</p>
                </article>
                <article>
                    <h3><strong>Frontend Design</strong></h3>
                    <p><strong>Frontend design</strong> refers to the process of designing and creating the visual and
                        interactive elements of a website that users interact with. This includes the layout, typography,
                        colors, images, and user interface components such as buttons and forms.</p>
                    <dl>
                        <dt><strong>Efficiency:</strong></dt>
                        <dd>Efficiency in web design means creating a website that allows users to achieve their goals in
                            the shortest amount of time possible. This can be achieved by designing a clear and intuitive
                            user interface, optimizing page load times, and minimizing the number of steps required to
                            complete a task.</dd>
                        <dt><strong>Accessibility:</strong></dt>
                        <dd>Accessibility in web design means creating a website that can be used by everyone, regardless
                            of their abilities or disabilities. This can be achieved by following web accessibility
                            guidelines and standards, using accessible fonts and colors, providing alternative text for
                            images, and ensuring that the website can be navigated using a keyboard.</dd>
                        <dt><strong>Usability:</strong></dt>
                        <dd>Usability in web design means creating a website that is easy to use and understand. This can
                            be achieved by designing a logical and intuitive navigation system, providing clear and
                            concise content, and ensuring that the website is responsive and works well on all devices and
                            screen sizes.</dd>
                        <dt><strong>Functionality:</strong></dt>
                        <dd>Functionality in web design means creating a website that works correctly and consistently.
                            This can be achieved by thoroughly testing the website on different devices and browsers,
                            ensuring that all links and interactive elements work as expected, and providing helpful error
                            messages when something goes wrong.</dd>
                    </dl>
                </article>
            </section>
        </main>
        <footer>
            <p>© 2023 Humayl Malik. All rights reserved.</p>
        </footer>
      </>
   );
}

export default HomePage;
