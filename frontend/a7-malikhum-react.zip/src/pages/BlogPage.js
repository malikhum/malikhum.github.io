import React from 'react';

function BlogPage() {
    return (
        <>
            <h2>Blog Posts</h2>
            <p>Paragraph introducing the blogging section of this app...</p>
            <article id="">
                <h3>Article Heading</h3>
                <p>Paragraphs ...</p>
            </article>
            <article id="">
            <h3>Article Heading</h3>
                <p>Paragraphs ...</p>
            </article>
            <article id="">
            <h3>Article Heading</h3>
                <p>Paragraphs ...</p>
            </article>
            <article id="">
            <h3>Article Heading</h3>
                <p>Paragraphs ...</p>
            </article>
        </>
    );
}

export default BlogPage;